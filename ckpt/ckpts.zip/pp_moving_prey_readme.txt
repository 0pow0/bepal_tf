there are 2 escape function in the env file.

the first escape function is hard prey
the second escape function is easy prey